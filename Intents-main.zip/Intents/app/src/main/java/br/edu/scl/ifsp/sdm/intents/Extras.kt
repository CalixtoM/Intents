package br.edu.scl.ifsp.sdm.intents

object Extras {
    const val PARAMETER_EXTRA = "PARAMETER_EXTRA"
}